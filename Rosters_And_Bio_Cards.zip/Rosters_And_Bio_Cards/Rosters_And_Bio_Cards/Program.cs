namespace Rosters_And_Bio_Cards
{
    class AthleteRecord
    {
        public string firstName = "";
        public string lastName = "";
        public int age = 0;
        public string classification = "";
    }

    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]

        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}